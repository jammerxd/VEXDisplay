global COLORS
COLORS={}
COLORS["White"] = (255,255,255)
COLORS["Black"] = (0,0,0)
COLORS["Red"] = (255,0,0)
COLORS["Green"] = (0,255,0)
COLORS["Blue"] = (0,0,255)

COLORS["vexRed"] = (218,38,46)
COLORS["vexBlue"] = (2,119,190)
COLORS["vexGreen"] = (0,150,0)
COLORS["vexTxtGray"] = (110,112,114)
COLORS["vexTxtGrayLighter"] = (130,132,134)
COLORS["vexBGLightGray"] = (215,217,219)
COLORS["vexBGDarkGray"] = (200,201,202)
COLORS["vexBGLighterGray"] = (233,234,235)
COLORS["vexBGDarkerGray"] = (150,151,152)
COLORS["vexInspectionPartialTxt"] = (180,131,3)