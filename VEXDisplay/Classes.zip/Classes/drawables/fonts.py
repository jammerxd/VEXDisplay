import wx
global Fonts
FONTS = {}
def genFonts():
    FONTS["NotoSansBold"] = wx.Font(56,wx.DEFAULT,wx.NORMAL,wx.BOLD,faceName="NotoSans")
    FONTS["NotoSansRegular"] = wx.Font(36,wx.DEFAULT,wx.NORMAL,wx.NORMAL,faceName="NotoSans")
    FONTS["NotoSansRegularI"] = wx.Font(36,wx.DEFAULT,wx.ITALIC,wx.NORMAL,faceName="NotoSans")
    FONTS["NotoSansRegularIU"] = wx.Font(36,wx.DEFAULT,wx.ITALIC,wx.NORMAL,faceName="NotoSans",underline=True)
    FONTS["NotoSansRegularIS"] = wx.Font(36,wx.DEFAULT,wx.ITALIC,wx.NORMAL,faceName="NotoSans")
    FONTS["NotoSansRegularIS"].SetStrikethrough(True)



