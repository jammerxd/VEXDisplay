import wx
import sys
import os
sys.path.append("..")
from ..EventData import *
from ..drawables.fonts import *
from ..Colors import *
 

class RankLogoPanel_Main(wx.Panel):
    def __init__(self,parent=None,img=None):
        wx.Panel.__init__(self,parent)
        self.SetDoubleBuffered(True)
        self.SetSize((1300,274))
        self.imgFilePath = img
        self.img = wx.StaticBitmap(self,-1,wx.BitmapFromImage(wx.Image(self.imgFilePath,wx.BITMAP_TYPE_PNG)))
        self.img.SetPosition(((self.GetSize()[0]-self.img.GetSize()[0])/2,(self.GetSize()[1]-self.img.GetSize()[1])/2))
    def updateImg(self,img):
        self.imgFilePath = img
        self.img.SetBitmap(wx.BitmapFromImage(wx.Image(self.imgFilePath,wx.BITMAP_TYPE_PNG)))
        self.img.SetPosition(((self.GetSize()[0]-self.img.GetSize()[0])/2,(self.GetSize()[1]-self.img.GetSize()[1])/2))
