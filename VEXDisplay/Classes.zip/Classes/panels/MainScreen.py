import wx, sys, os
sys.path.append('..')
from ..Colors import *
from RanksPanel import *
from InspectionsPanel import *
from ..data import *
from ..EventData import *
from ..drawables import *
class MainScreen(wx.Panel):
    def __init__(self,parent):
        wx.Panel.__init__(self,parent)
        self.SetSize((1920,1080))
        self.SetBackgroundColour(COLORS["vexRed"])
        self.mainPanel = None
        self.secondPanel = None

        self.smallLogoPic = None
        self.logoTimer = None
        self.logoRect = None
        
        self.mainPanelHeader = None
        self.secondPanelHeader = None

        self.Font_NotoSans_22_Normal = None
        self.Font_NotoSans_22_Bold = None

        #self.SetBackgroundColour(COLORS["Black"])
    def onReady(self,mainPanel = "Rankings", secondPanel = "Matches", showInspections=False):
        self.mainPanelType = mainPanel
        self.secondPanelType = secondPanel
        self.showInspections = showInspections


        ###SETUP FONTS AND HEADERS###
        if os.name == 'nt':
            self.Font_NotoSans_22_Normal = wx.Font(22,wx.DEFAULT,wx.NORMAL,wx.NORMAL,faceName="Noto Sans")
            self.Font_NotoSans_22_Bold = wx.Font(22,wx.DEFAULT,wx.NORMAL,wx.BOLD,faceName="Noto Sans")

            self.Font_NotoSans_55_Normal = wx.Font(55,wx.DEFAULT,wx.NORMAL,wx.NORMAL,faceName="Noto Sans")
            self.Font_NotoSans_55_Bold = wx.Font(55,wx.DEFAULT,wx.NORMAL,wx.BOLD,faceName="Noto Sans")
        else:
            self.Font_NotoSans_22_Normal = wx.Font(22,wx.DEFAULT,wx.NORMAL,wx.NORMAL,faceName="NotoSans")
            self.Font_NotoSans_22_Bold = wx.Font(22,wx.DEFAULT,wx.NORMAL,wx.BOLD,faceName="NotoSans")

            self.Font_NotoSans_55_Normal = wx.Font(55,wx.DEFAULT,wx.NORMAL,wx.NORMAL,faceName="NotoSans")
            self.Font_NotoSans_55_Bold = wx.Font(55,wx.DEFAULT,wx.NORMAL,wx.BOLD,faceName="NotoSans")
        
        #Determine main panel
        if mainPanel == "Rankings":
            self.mainPanelHeader = Header(self,-1,"Qualification Rankings",self.Font_NotoSans_55_Bold,COLORS["White"])
            self.mainPanelHeader.SetPosition((250,12))
            self.mainPanelHeader.SetSize((830,150))
        #########
        #Check if inspections are needed
        if self.showInspections:
            self.secondPanel = None
            self.mainPanel = InspectionsPanel(self)
            self.mainPanelHeader.SetLabel("Team Inspections")
            self.mainPanelHeader.SetPosition(((self.GetSize()[0]-self.mainPanelHeader.GetSize()[0])/2,12))
            self.SetBackgroundColour(COLORS["vexBGDarkerGray"])
        else:
            self.mainPanel = RanksPanel(self)
            self.mainPanelHeader.SetPosition((250,12))
        #########
        ###show panels###
        if self.mainPanel != None:
            self.mainPanel.Show()   
        
        if self.secondPanel != None:
            self.secondPanel.Show()
        