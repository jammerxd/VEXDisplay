import wx
import sys
sys.path.append('..')
from ..Colors import *
from ..EventData import *
from TeamInspectionPanel_Small import *
class InspectionsPanel(wx.Panel):
    def __init__(self,parent=None):
        wx.Panel.__init__(self,parent)
        self.SetSize((1870,900))
        self.SetPosition((25,165))
        self.SetBackgroundColour(COLORS["vexBGDarkerGray"])
        self.redrawTimer = wx.Timer(self,-1)
        self.Bind(wx.EVT_TIMER,self.redraw,self.redrawTimer)
        self.Bind(wx.EVT_SHOW,self.doClose)
        self.NotoSansBold = wx.Font(18,wx.DEFAULT,wx.NORMAL,wx.BOLD,faceName="NotoSans")
        self.NotoSansRegular = wx.Font(36,wx.DEFAULT,wx.NORMAL,wx.NORMAL,faceName="NotoSans")
        self.NotoSansRegularI = wx.Font(36,wx.DEFAULT,wx.ITALIC,wx.NORMAL,faceName="NotoSans")
        self.NotoSansRegularIU = wx.Font(36,wx.DEFAULT,wx.ITALIC,wx.NORMAL,faceName="NotoSans",underline=True)
        self.NotoSansRegularIS = wx.Font(36,wx.DEFAULT,wx.ITALIC,wx.NORMAL,faceName="NotoSans")
        self.NotoSansRegularIS.SetStrikethrough(True)
       
        self.xOff = 35

        self.teamLblHandler = {}

        self.teamLblOffsetX = self.xOff
        self.teamLblOffsetY = 0
        


        for team in EVENT_DATA.teams:
            self.teamLblHandler[team] = TeamInspectionPanel(self)
            self.teamLblHandler[team].lblTeamNumber = wx.StaticText(self.teamLblHandler[team],-1)
            self.teamLblHandler[team].lblTeamNumber.SetFont(self.NotoSansRegular)
            if (EVENT_DATA.teams[team].getCheckedIn()):
                if (EVENT_DATA.teams[team].getInspectionStatus() == "Not Started"):
                    self.teamLblHandler[team].lblTeamNumber.SetForegroundColour(COLORS["vexRed"])
                    self.teamLblHandler[team].lblTeamNumber.SetFont(self.NotoSansRegular)
                    if self.teamLblHandler[team].strikeThrough.IsShown():
                        self.teamLblHandler[team].strikeThrough.Hide()
                elif (EVENT_DATA.teams[team].getInspectionStatus() == "Partial"):
                    self.teamLblHandler[team].lblTeamNumber.SetForegroundColour(COLORS["vexInspectionPartialTxt"])
                    self.teamLblHandler[team].lblTeamNumber.SetFont(self.NotoSansRegularIU)
                elif (EVENT_DATA.teams[team].getInspectionStatus() == "Completed"):
                    self.teamLblHandler[team].lblTeamNumber.SetForegroundColour(COLORS["vexGreen"])
                    self.teamLblHandler[team].lblTeamNumber.SetFont(self.NotoSansRegularIS)
            else:
                self.teamLblHandler[team].lblTeamNumber.SetForegroundColour(COLORS["vexTxtGray"])
                self.teamLblHandler[team].lblTeamNumber.SetFont(self.NotoSansRegularI)
            self.teamLblHandler[team].lblTeamNumber.SetLabel(team)
            self.teamLblHandler[team].lblTeamNumber.SetPosition(((self.teamLblHandler[team].GetSize()[0]-self.teamLblHandler[team].lblTeamNumber.GetSize()[0])/2,(self.teamLblHandler[team].GetSize()[1]-self.teamLblHandler[team].lblTeamNumber.GetSize()[1])/2))
            self.teamLblHandler[team].SetPosition((self.teamLblOffsetX,self.teamLblOffsetY))
            self.teamLblHandler[team].SetBackgroundColour(COLORS["vexBGLightGray"])
            
            if (self.teamLblOffsetX >= 1150):
                self.teamLblOffsetY += 70
                self.teamLblOffsetX = self.xOff

            else:
                self.teamLblOffsetX += 360
        
        self.redrawTimer.Start(1000)

    def redraw(self,evt):
        for team in self.teamLblHandler:
            if (EVENT_DATA.teams[team].getCheckedIn()):
                if (EVENT_DATA.teams[team].getInspectionStatus() == "Not Started"):
                    self.teamLblHandler[team].lblTeamNumber.SetForegroundColour(COLORS["vexRed"])
                    self.teamLblHandler[team].lblTeamNumber.SetFont(self.NotoSansRegular)
                elif (EVENT_DATA.teams[team].getInspectionStatus() == "Partial"):
                    self.teamLblHandler[team].lblTeamNumber.SetForegroundColour(COLORS["vexInspectionPartialTxt"])
                    self.teamLblHandler[team].lblTeamNumber.SetFont(self.NotoSansRegularIU)
                elif (EVENT_DATA.teams[team].getInspectionStatus() == "Completed"):
                    self.teamLblHandler[team].lblTeamNumber.SetForegroundColour(COLORS["vexGreen"])
                    self.teamLblHandler[team].lblTeamNumber.SetFont(self.NotoSansRegularIS)
            else:
                self.teamLblHandler[team].lblTeamNumber.SetForegroundColour(COLORS["vexTxtGray"])
                self.teamLblHandler[team].lblTeamNumber.SetFont(self.NotoSansRegularI)
            #self.teamLblHandler[team].lblTeamNumber.Update()
            self.teamLblHandler[team].lblTeamNumber.Refresh()
            #self.teamLblHandler[team].Update()
            #self.teamLblHandler[team].Refresh()
            #self.Refresh()

    def doClose(self,evt,show=False):
        if self.redrawTimer != None and show==False:
            if self.redrawTimer.IsRunning():
                self.redrawTimer.Stop()