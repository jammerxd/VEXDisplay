import wx, sys
sys.path.append("..")
from ..Colors import *
from ..EventData import *
class TeamInspectionPanel(wx.Panel):

    def __init__(self,parent=None):
        wx.Panel.__init__(self,parent)
        self.SetSize((350,60))
        self.SetPosition((10,15))
        self.lblTeamNumber = None
        self.strikeThrough = wx.Panel(self,-1)
        self.strikeThrough.SetSize((300,5))
        self.strikeThrough.SetPosition((25,50))
        self.strikeThrough.Hide()