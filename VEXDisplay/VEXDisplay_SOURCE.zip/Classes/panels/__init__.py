from ConfigureDisplay import *
from MainScreen import *
from RanksPanel import *
from InspectionsPanel import *